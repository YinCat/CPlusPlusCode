#include "Maze.h"

int main()
{
	TestMaze();
	system("pause");
	return 0;
}